# This files contains your custom actions which can be used to run
# custom Python code.
#
# See this guide on how to implement these action:
# https://rasa.com/docs/rasa/custom-actions


# This is a simple example for a custom action which utters "Hello World!"

from typing import Any, Text, Dict, List

from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.events import SlotSet, AllSlotsReset
import sys
import requests

#
#
# class ActionHelloWorld(Action):
#
#     def name(self) -> Text:
#         return "action_hello_world"
#
#     def run(self, dispatcher: CollectingDispatcher,
#             tracker: Tracker,
#             domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
#
#         dispatcher.utter_message(text="Hello World!")
#
#         return []

class ClearSlots(Action):

	def name(self) -> Text:
		return "action_clear_slots"

	def run(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

		#limpa slots do agendamento
		return [AllSlotsReset()]

class SubmeterConsulta(Action):

    def name(self) -> Text:
        return "action_submeter_consulta"

    def run(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

		#recebe dados dos slots
        capital = tracker.get_slot('capital')
        campo_passagem = {1: capital}
        #executa alguma coisa com os dados

        params = {
        'access_key': 'ac9df42ee2b3995e6a015fb66e7b3d89',
        #'query': dict['capital'],
        'query': campo_passagem[1],
        'unit': 'm'
        }

        api_result = requests.get('http://api.weatherstack.com/current', params)
        api_response = api_result.json()

        texto_01 = 'Em ' + str(api_response['location']['name']) 
        texto_02 = ', ' + str(api_response['location']['region'])
        texto_03 = ', a temperatura está ' + str(api_response['current']['temperature']) 
        texto_04 = 'ºC. A umidade do ar está em ' + str(api_response['current']['humidity']) 
        texto_05 = '%. Estes dados foram coletados às ' 
        texto_06 = str(api_response['location']['localtime'])
        texto_07 = '. Espero ter ajudado!'
        texto_final = texto_01 + texto_02 + texto_03 + texto_04 + texto_05 + texto_06 + texto_07
        resultado = str(texto_final)

		#retorna o resultado
        return [SlotSet("resultado_consulta", resultado)]
